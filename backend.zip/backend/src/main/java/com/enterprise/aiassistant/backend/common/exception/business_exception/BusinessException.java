package com.enterprise.aiassistant.backend.common.exception.business_exception;

import com.enterprise.aiassistant.backend.common.exception.ErrorCode;
import lombok.Getter;

@Getter
public class BusinessException extends RuntimeException {
    private final ErrorCode errorCode;


    public BusinessException(ErrorCode errorCode) {
        super(errorCode.getMessage());
        this.errorCode = errorCode;
    }

    public BusinessException(
            ErrorCode errorCode,
            String message
    ){
        super(message);
        this.errorCode = errorCode;
    }


    public BusinessException(
            ErrorCode errorCode,
            String message,
            Throwable cause
    ){
        super(message, cause);
        this.errorCode = errorCode;
    }
}
