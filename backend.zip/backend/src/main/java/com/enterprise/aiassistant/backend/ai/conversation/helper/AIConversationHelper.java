package com.enterprise.aiassistant.backend.ai.conversation.helper;

import java.util.Locale;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.enterprise.aiassistant.backend.ai.conversation.dto.request.ConversationFilterRequest;
import com.enterprise.aiassistant.backend.common.exception.ErrorCode;
import com.enterprise.aiassistant.backend.common.exception.business_exception.AIConversationException;
import com.enterprise.aiassistant.backend.common.exception.business_exception.BusinessException;

@Component
public class AIConversationHelper {

    private final Set<String> ALLOWED_SORTS = Set.of("newest", "oldest");

    public void validateFilter(ConversationFilterRequest filter) {

        if (filter == null) {
            return;
        }

        if (filter.getSort() != null
                && !ALLOWED_SORTS.contains(filter.getSort().toLowerCase(Locale.ROOT))) {
            throw new BusinessException(ErrorCode.INVALID_SORT_OPTION);
        }

        if (filter.getFromDate() != null
                && filter.getToDate() != null
                && filter.getFromDate().isAfter(filter.getToDate())) {
            throw new BusinessException(ErrorCode.INVALID_DATE_RANGE);
        }

        if (filter.getKeyword() != null && filter.getKeyword().length() > 255) {
            throw new BusinessException(ErrorCode.KEYWORD_TOO_LONG);
        }
    }

    public void validateConversationId(Long conversationId) {

        if (conversationId == null) {
            throw new AIConversationException(ErrorCode.CONVERSATION_ID_REQUIRED);
        }

        if (conversationId <= 0) {
            throw new AIConversationException(ErrorCode.CONVERSATION_ID_INVALID);
        }
    }
}
