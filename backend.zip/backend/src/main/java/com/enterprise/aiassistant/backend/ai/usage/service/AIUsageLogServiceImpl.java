package com.enterprise.aiassistant.backend.ai.usage.service;

import com.enterprise.aiassistant.backend.ai.usage.dto.AIUsageLogFilterRequest;
import com.enterprise.aiassistant.backend.ai.usage.dto.AIUsageLogResponse;
import com.enterprise.aiassistant.backend.ai.usage.dto.AIUsageSummaryResponse;
import com.enterprise.aiassistant.backend.ai.usage.entity.AIUsageLog;
import com.enterprise.aiassistant.backend.ai.usage.enums.AIUsageStatus;
import com.enterprise.aiassistant.backend.ai.usage.helper.AIUsageLogSpecifications;
import com.enterprise.aiassistant.backend.ai.usage.repository.AIUsageLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.enterprise.aiassistant.backend.ai.usage.mapper.AIUsageLogMapper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;

@Service
@RequiredArgsConstructor
public class AIUsageLogServiceImpl implements AIUsageLogService {
    private final AIUsageLogMapper mapper;
    private final AIUsageLogRepository repository;

    @Override
    @Transactional
    public void log(
            String featureType,
            String model,
            Integer inputTokens,
            Integer outputTokens,
            BigDecimal estimatedCost,
            AIUsageStatus status,
            String errorMessage
    ) {
        AIUsageLog entity = AIUsageLog.builder()
                .featureType(featureType)
                .model(model)
                .inputTokens(inputTokens != null ? inputTokens : 0)
                .outputTokens(outputTokens != null ? outputTokens : 0)
                .estimatedCost(estimatedCost != null ? estimatedCost : BigDecimal.ZERO)
                .status(status)
                .errorMessage(errorMessage)
                .build();

        repository.save(entity);
    }

    @Override
    public Page<AIUsageLogResponse> getUsageLogs(AIUsageLogFilterRequest filter, Pageable pageable) {
        return repository.findAll(AIUsageLogSpecifications.byFilter(filter), pageable)
                .map(mapper::toResponse);
    }

    @Override
    public AIUsageSummaryResponse getSummary() {
        LocalDateTime startOfToday = LocalDate.now().atStartOfDay();
        LocalDateTime startOfMonth = LocalDate.now()
                .with(TemporalAdjusters.firstDayOfMonth())
                .atStartOfDay();

        long totalRequests = repository.count();
        long todayRequests = repository.countByCreatedAtGreaterThanEqual(startOfToday);
        long successCount = repository.countByStatus(AIUsageStatus.SUCCESS);
        long errorCount = repository.countByStatus(AIUsageStatus.FAILED);

        // Token & cost tổng hợp nên đẩy xuống 1 query aggregate (@Query) khi
        // dữ liệu lớn — tạm thời demo bằng cách duyệt findAll() theo tháng.
        var thisMonthLogs = repository.findAll(
                AIUsageLogSpecifications.byFilter(monthFilter(startOfMonth))
        );

        long totalInputTokens = thisMonthLogs.stream().mapToLong(AIUsageLog::getInputTokens).sum();
        long totalOutputTokens = thisMonthLogs.stream().mapToLong(AIUsageLog::getOutputTokens).sum();
        BigDecimal costThisMonth = thisMonthLogs.stream()
                .map(AIUsageLog::getEstimatedCost)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        double successRate = totalRequests == 0
                ? 0
                : (double) successCount / totalRequests * 100;

        return AIUsageSummaryResponse.builder()
                .totalRequests(totalRequests)
                .todayRequests(todayRequests)
                .totalInputTokens(totalInputTokens)
                .totalOutputTokens(totalOutputTokens)
                .totalTokens(totalInputTokens + totalOutputTokens)
                .estimatedCostThisMonth(costThisMonth)
                .successCount(successCount)
                .errorCount(errorCount)
                .successRate(successRate)
                .build();
    }

    private AIUsageLogFilterRequest monthFilter(LocalDateTime from) {
        var f = new AIUsageLogFilterRequest();
        f.setFromDate(from);
        return f;
    }

   
}