package com.enterprise.aiassistant.backend.ai.usage.mapper;

import com.enterprise.aiassistant.backend.ai.usage.dto.AIUsageLogResponse;
import com.enterprise.aiassistant.backend.ai.usage.entity.AIUsageLog;
import org.springframework.stereotype.Component;

@Component
public class AIUsageLogMapper {

    public AIUsageLogResponse toResponse(AIUsageLog entity) {
        return AIUsageLogResponse.builder()
                .id(entity.getId())
                .createdAt(entity.getCreatedAt())
                .featureType(entity.getFeatureType())
                .model(entity.getModel())
                .inputTokens(entity.getInputTokens())
                .outputTokens(entity.getOutputTokens())
                .totalTokens(entity.getTotalTokens())
                .estimatedCost(entity.getEstimatedCost())
                .status(entity.getStatus())
                .build();
    }
}