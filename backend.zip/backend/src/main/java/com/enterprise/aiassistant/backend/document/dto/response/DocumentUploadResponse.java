package com.enterprise.aiassistant.backend.document.dto.response;

import com.enterprise.aiassistant.backend.document.enums.DocumentStatus;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DocumentUploadResponse {

    private Long documentId;

    private Long currentVersionId;

    private String title;

    private String filename;

    private int versionNumber;

    private DocumentStatus status;
}